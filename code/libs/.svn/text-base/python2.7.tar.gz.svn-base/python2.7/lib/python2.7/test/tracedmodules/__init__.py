"""This package contains modules that help testing the trace.py module. Note
that the exact location of functions in these modules is important, as trace.py
takes the real line numbers into account.
"""
